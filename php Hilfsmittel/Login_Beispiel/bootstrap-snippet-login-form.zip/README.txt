A Pen created at CodePen.io. You can find this one at http://codepen.io/ace-subido/pen/Cuiep.

 Using default Bootstrap 3.0, here's a short CSS snippet to style your login form.