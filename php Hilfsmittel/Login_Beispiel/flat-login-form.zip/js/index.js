$('.login-header p').click(function() {
  $('.login-container').hide(300);
});